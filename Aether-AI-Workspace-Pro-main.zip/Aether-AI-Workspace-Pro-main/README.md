# Aether AI Workspace Pro

A professional Arabic-first web workspace designed to connect to the **OpenAI-compatible model gateway** of [Free-Cloud-AI-Agent](https://github.com/Ahmadkhaled11/Free-Cloud-AI-Agent).

> This is a secure companion UI/proxy. It does not replace the upstream Nanobot service or automatically deploy the upstream Docker Compose stack. The chat screen talks to the configured gateway `/v1/chat/completions`; it does not magically gain Nanobot workspace tools unless the upstream architecture exposes them through the configured API.

## Included

- RTL Arabic UI + English mode
- Login gate with HTTP-only signed session cookie
- Server-side credentials; provider/gateway keys never enter browser JavaScript
- Streaming chat UI with error handling
- Model list endpoint with configured-model fallback
- Browser-local chat history, search, export and import
- Text/Markdown/CSV/JSON/code attachments converted to prompt context locally
- Prompt templates, keyboard shortcuts, mobile sidebar
- Dockerfile and Render Blueprint
- Arabic guides for GitHub ZIP upload and Render setup

## Deploy the companion UI

### Required Render environment variables

- `AGENT_API_BASE_URL`: reachable URL ending in `/v1`
- `AGENT_API_KEY`: the **gateway token** from the upstream setup, not your provider API key
- `AGENT_MODEL`: model ID accepted by the gateway, e.g. `openrouter/free`
- `APP_PASSWORD`: strong password for the website login
- `APP_SECRET`: random secret used to sign sessions; use 32+ random characters

Never commit real secrets to GitHub. The `.env` file is ignored.

### Local run

Node.js 20+:

```bash
cp .env.example .env
# Edit .env and set all values
npm install
npm start
```

Open `http://localhost:3000`.

### Deploy on Render

Create a **Web Service** connected to this GitHub repository and choose Docker runtime. The included `render.yaml` can be used as a Blueprint. Set the environment variables in Render's Environment panel and deploy.

The upstream gateway must already be reachable from Render. `127.0.0.1` only works when the gateway is inside the same network namespace; it is not the address of your other Render service.

## Upstream compatibility and limits

The original repository's gateway supports text chat and function tools, while native image/audio/video model inputs are not supported by that starter. This companion currently supports text-oriented chat and text-like file context; it does not upload files to the agent, execute tools by itself, or implement user accounts/multi-user isolation.

Render free web services may sleep and do not provide persistent disks. Chat history here is stored in each browser's local storage. Do not treat it as a server-side backup or store highly sensitive data in a shared device browser.

Read the upstream [README](https://github.com/Ahmadkhaled11/Free-Cloud-AI-Agent), [security policy](https://github.com/Ahmadkhaled11/Free-Cloud-AI-Agent/blob/main/SECURITY.md), and [cloud hosting notes](https://github.com/Ahmadkhaled11/Free-Cloud-AI-Agent/blob/main/docs/clouds.md) before public deployment.

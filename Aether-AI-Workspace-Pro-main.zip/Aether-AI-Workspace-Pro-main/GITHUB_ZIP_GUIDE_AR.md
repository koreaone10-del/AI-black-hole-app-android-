# دليل رفع Aether AI إلى GitHub من هاتف Android عبر ZIP

## مهم قبل البداية

رفع ملف ZIP نفسه إلى مستودع GitHub لا يجعل GitHub يفكّه تلقائياً، وRender لا ينشر ملف ZIP خاماً كمشروع. يجب فك الضغط ثم رفع ملفات المشروع ومجلداته إلى المستودع.

## الطريقة الموصى بها من الهاتف

### 1) نزّل الملف وفك الضغط
1. نزّل `Aether-AI-Workspace-Pro.zip`.
2. افتح تطبيق الملفات أو ZArchiver.
3. فك الضغط إلى مجلد واضح مثل `Download/Aether-AI-Workspace-Pro`.
4. تأكد أن `package.json` و`server.js` و`Dockerfile` و`render.yaml` موجودة مباشرة داخل المجلد، وأن مجلد `public` يحتوي الواجهة.

### 2) أنشئ المستودع
1. افتح GitHub وسجّل الدخول.
2. اضغط `+` ثم `New repository`.
3. الاسم المقترح: `Aether-AI-Workspace-Pro`.
4. اجعله Private إذا كان المشروع للاستخدام الشخصي.
5. أنشئ المستودع فارغاً؛ لا تضف README من GitHub لأن المشروع يحتوي README جاهزاً.

### 3) أسهل طريقة عملية عبر Termux
إذا كان Termux مثبتاً على هاتفك:
1. افتح Termux واكتب:

```bash
termux-setup-storage
pkg update
pkg install git
cd ~/storage/downloads
unzip -o Aether-AI-Workspace-Pro.zip
cd Aether-AI-Workspace-Pro
git init
git branch -M main
git add .
git status
```

2. راجع `git status` وتأكد أن `.env` غير موجود. ملف `.env.example` فقط آمن لأنه يحتوي قيماً تجريبية.
3. اربط المستودع الذي أنشأته (استبدل `YOUR_GITHUB_USERNAME` باسم حسابك):

```bash
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/Aether-AI-Workspace-Pro.git
git commit -m "Initial Aether AI Workspace Pro"
git push -u origin main
```

4. إذا طلب GitHub مصادقة، استخدم آلية تسجيل الدخول التي يوفرها Git أو رمز وصول محدود الصلاحيات للمستودع نفسه. لا ترسل الرمز في المحادثة ولا تضعه في ملفات المشروع. إذا طلب Git كلمة مرور للحساب، فإن كلمة مرور الحساب العادية لا تعمل كبديل لرمز الوصول.

### 4) إذا أردت الرفع من متصفح GitHub فقط
افتح المستودع ثم `Add file` → `Upload files` وارفع **محتويات المجلد بعد فك الضغط**، لا ملف ZIP وحده. قد تكون إدارة المجلدات المتداخلة صعبة من الهاتف؛ إذا لم يحافظ المتصفح على بنية `public/` فاستعمل Termux أعلاه.

## بعد الرفع
افتح تبويب `Code` في المستودع وتأكد من ظهور `server.js` و`Dockerfile` و`render.yaml` ومجلد `public/` في الجذر. لا ترفع `node_modules` أو `.env` أو أي مفاتيح حقيقية.

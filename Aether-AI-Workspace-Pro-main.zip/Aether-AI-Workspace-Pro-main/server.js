import express from "express";
import helmet from "helmet";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3000);
const base = (process.env.AGENT_API_BASE_URL || "").replace(/\/+$/, "");
const apiKey = process.env.AGENT_API_KEY || "";
const defaultModel = process.env.AGENT_MODEL || "openrouter/free";
const appPassword = process.env.APP_PASSWORD || "";
const appSecret = process.env.APP_SECRET || "";
const COOKIE = "aether_session";
const SESSION_SECONDS = 60 * 60 * 24 * 7;
const loginAttempts = new Map();

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: []
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "1mb" }));

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function sign(value) {
  return crypto.createHmac("sha256", appSecret).update(value).digest("base64url");
}
function makeSession() {
  const expires = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const value = `${expires}`;
  return `${value}.${sign(value)}`;
}
function isAuthenticated(req) {
  if (!appPassword || appSecret.length < 32) return false;
  const raw = req.headers.cookie || "";
  const pair = raw.split(";").map(v => v.trim()).find(v => v.startsWith(`${COOKIE}=`));
  if (!pair) return false;
  const token = decodeURIComponent(pair.slice(COOKIE.length + 1));
  const dot = token.indexOf(".");
  if (dot < 1) return false;
  const expires = token.slice(0, dot);
  const signature = token.slice(dot + 1);
  return /^\d+$/.test(expires) && Number(expires) > Math.floor(Date.now()/1000) && safeEqual(signature, sign(expires));
}
function requireAuth(req, res, next) {
  if (isAuthenticated(req)) return next();
  return res.status(401).json({ error: "Please sign in to continue." });
}
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "aether-ai-workspace-pro", configured: Boolean(base && apiKey), authConfigured: Boolean(appPassword && appSecret.length >= 32) });
});
app.get("/api/session", (req, res) => {
  res.json({ authenticated: isAuthenticated(req), loginConfigured: Boolean(appPassword && appSecret.length >= 32) });
});
app.post("/api/login", (req, res) => {
  if (!appPassword || appSecret.length < 32) return res.status(503).json({ error: "Website login is not configured. Set APP_PASSWORD and APP_SECRET in the server environment." });
  const now = Date.now();
  const ip = String(req.ip || "unknown");
  const record = loginAttempts.get(ip) || { count: 0, resetAt: now + 10 * 60 * 1000 };
  if (now > record.resetAt) { record.count = 0; record.resetAt = now + 10 * 60 * 1000; }
  if (record.count >= 10) return res.status(429).json({ error: "Too many login attempts. Wait 10 minutes and try again." });
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  if (!safeEqual(password, appPassword)) {
    record.count += 1; loginAttempts.set(ip, record);
    return res.status(401).json({ error: "Incorrect password." });
  }
  loginAttempts.delete(ip);
  const secure = req.secure || process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `${COOKIE}=${encodeURIComponent(makeSession())}; HttpOnly${secure}; SameSite=Strict; Path=/; Max-Age=${SESSION_SECONDS}`);
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => {
  const secure = req.secure || process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `${COOKIE}=; HttpOnly${secure}; SameSite=Strict; Path=/; Max-Age=0`);
  res.json({ ok: true });
});
app.get("/api/config", requireAuth, (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({ model: defaultModel, configured: Boolean(base && apiKey) });
});
app.get("/api/models", requireAuth, async (_req, res) => {
  if (!base || !apiKey) return res.json({ data: [{ id: defaultModel, name: defaultModel }], fallback: true });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const upstream = await fetch(`${base}/models`, { headers: { authorization: `Bearer ${apiKey}`, accept: "application/json" }, signal: controller.signal });
    if (!upstream.ok) return res.json({ data: [{ id: defaultModel, name: defaultModel }], fallback: true });
    const payload = await upstream.json();
    const data = Array.isArray(payload?.data) ? payload.data.map(m => ({ id: String(m.id || ""), name: String(m.name || m.id || "") })).filter(m => m.id) : [];
    if (!data.some(m => m.id === defaultModel)) data.unshift({ id: defaultModel, name: defaultModel });
    res.set("Cache-Control", "no-store");
    res.json({ data, fallback: false });
  } catch {
    res.json({ data: [{ id: defaultModel, name: defaultModel }], fallback: true });
  } finally { clearTimeout(timer); }
});
app.post("/api/chat", requireAuth, async (req, res) => {
  if (!base || !apiKey) return res.status(503).json({ error: "The model gateway is not configured on the server." });
  const { messages, model, stream = true } = req.body || {};
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 60) return res.status(400).json({ error: "messages must contain 1–60 entries." });
  const normalized = messages.map(m => ({
    role: ["system", "user", "assistant"].includes(m?.role) ? m.role : "user",
    content: typeof m?.content === "string" ? m.content.slice(0, 24000) : ""
  })).filter(m => m.content.trim());
  if (!normalized.length) return res.status(400).json({ error: "Message content is empty." });

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 120000);
  try {
    const upstream = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json", "authorization": `Bearer ${apiKey}`, "accept": stream ? "text/event-stream" : "application/json" },
      body: JSON.stringify({ model: typeof model === "string" && model.trim() ? model.trim().slice(0, 200) : defaultModel, messages: normalized, stream: Boolean(stream) }),
      signal: controller.signal
    });
    if (!upstream.ok) {
      const detail = (await upstream.text()).slice(0, 1200);
      return res.status(upstream.status).json({ error: "The model gateway returned an error.", detail });
    }
    if (!stream) {
      res.set("Cache-Control", "no-store");
      return res.status(200).json(await upstream.json());
    }
    res.status(200).set({
      "Content-Type": upstream.headers.get("content-type") || "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no"
    });
    if (!upstream.body) return res.end();
    const reader = upstream.body.getReader();
    res.on("close", () => { if (!res.writableEnded) controller.abort(); });
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (!res.writableEnded) res.write(Buffer.from(value));
      }
    } finally { if (!res.writableEnded) res.end(); }
  } catch (err) {
    if (!res.headersSent) {
      const timeout = err?.name === "AbortError";
      res.status(timeout ? 504 : 502).json({ error: timeout ? "The model request timed out." : "Could not connect to the configured model gateway." });
    } else if (!res.writableEnded) res.end();
  } finally { clearTimeout(timer); }
});

app.use(express.static(path.join(here, "public"), { maxAge: "1h", etag: true }));
app.get("*", (_req, res) => res.sendFile(path.join(here, "public", "index.html")));
app.listen(port, "0.0.0.0", () => console.log(`Aether AI Workspace Pro listening on ${port}`));

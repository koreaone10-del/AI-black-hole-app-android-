const $=s=>document.querySelector(s);
const welcome=$("#welcome"),messagesEl=$("#messages"),form=$("#chatForm"),input=$("#promptInput"),sendBtn=$("#sendBtn"),modelSelect=$("#modelSelect"),toastEl=$("#toast");
const HISTORY_KEY="aether.pro.history.v2",THEME_KEY="aether.pro.theme.v1",LANG_KEY="aether.pro.lang.v1";
let language=localStorage.getItem(LANG_KEY)||"ar",chats=[],currentId=null,busy=false,attachments=[],loggedIn=false;

const tr={
ar:{
newChat:"محادثة جديدة",workspace:"مساحة العمل",assistant:"المساعد الذكي",history:"المحادثات",promptLibrary:"مكتبة الأوامر",recent:"الأحدث",gatewayStatus:"حالة البوابة",privateSession:"جلسة شخصية خاصة",private:"خاص",eyebrow:"مساحة تفكيرك القادمة",line1:"حوّل أفكارك إلى",line2:"إنجازات ملموسة.",welcomeText:"مساحة واحدة للبحث والتحليل والكتابة والبرمجة. ابدأ بفكرة، وواصل العمل حتى تصبح خطة واضحة.",cap1:"تحليل",cap2:"برمجة",cap3:"كتابة",cap4:"تخطيط",card1Title:"ابنِ مشروعاً",card1Text:"من الفكرة إلى خارطة طريق",card2Title:"مختبر البرمجة",card2Text:"تشخيص، إصلاح، وتحسين",card3Title:"بحث معمّق",card3Text:"أفكار منظمة وقرارات أفضل",card4Title:"خطّة تنفيذ",card4Text:"أولويات ومخرجات قابلة للقياس",placeholder:"اكتب رسالتك هنا… استخدم Shift + Enter لسطر جديد",attach:"إرفاق ملف نصي",send:"إرسال",disclaimer:"قد يخطئ الذكاء الاصطناعي. راجع المعلومات المهمة.",you:"أنت",ai:"Aether AI",empty:"لا توجد محادثات بعد",checking:"جارٍ الفحص…",connected:"البوابة مهيأة",notConfigured:"تحقق من إعدادات البوابة",connectionError:"تعذّر فحص الاتصال",requestError:"تعذّر إكمال الطلب.",clearConfirm:"مسح رسائل المحادثة الحالية؟",copied:"تم النسخ",untitled:"محادثة جديدة",newConversation:"بدأت محادثة جديدة",promptTitle:"مكتبة الأوامر الجاهزة",promptDesc:"اختر قالباً ثم عدّله حسب مهمتك.",loadModels:"تعذّر تحميل النماذج",loginMissing:"إعداد الدخول غير مكتمل على الخادم.",fileType:"نوع الملف غير مدعوم.",fileLarge:"الملف أكبر من 150 KB.",fileRead:"تعذّرت قراءة الملف.",filesAdded:"تمت إضافة الملفات إلى الرسالة.",noMessages:"لا توجد رسائل لتصديرها.",historyTitle:"المحادثات"
},
en:{
newChat:"New chat",workspace:"Workspace",assistant:"AI assistant",history:"Conversations",promptLibrary:"Prompt library",recent:"RECENT",gatewayStatus:"Gateway status",privateSession:"Private workspace",private:"Private",eyebrow:"YOUR NEXT THINKING SPACE",line1:"Turn ideas into",line2:"meaningful progress.",welcomeText:"One focused space for research, analysis, writing, and coding. Start with an idea and turn it into a clear plan.",cap1:"Analysis",cap2:"Coding",cap3:"Writing",cap4:"Planning",card1Title:"Build a project",card1Text:"From idea to roadmap",card2Title:"Code lab",card2Text:"Diagnose, fix, improve",card3Title:"Deep research",card3Text:"Structured thinking and better decisions",card4Title:"Execution plan",card4Text:"Priorities and measurable outcomes",placeholder:"Write your message… Shift + Enter for a new line",attach:"Attach text file",send:"Send",disclaimer:"AI can make mistakes. Verify important information.",you:"You",ai:"Aether AI",empty:"No conversations yet",checking:"Checking…",connected:"Gateway configured",notConfigured:"Check gateway settings",connectionError:"Connection check failed",requestError:"The request failed.",clearConfirm:"Clear the current conversation?",copied:"Copied",untitled:"New conversation",newConversation:"New conversation started",promptTitle:"Prompt library",promptDesc:"Choose a template and adapt it to your task.",loadModels:"Could not load models",loginMissing:"Website login is not configured on the server.",fileType:"Unsupported file type.",fileLarge:"File exceeds 150 KB.",fileRead:"Could not read file.",filesAdded:"Files attached to your message.",noMessages:"There are no messages to export.",historyTitle:"Conversations"
}
};

function t(k){
return tr[language][k]||k;
}

function toast(s){
toastEl.textContent=s;
toastEl.classList.add("show");
setTimeout(()=>toastEl.classList.remove("show"),2600);
}

function closeSidebar(){
$("#sidebar").classList.remove("open");
}

function setLanguage(lang){
language=lang;
localStorage.setItem(LANG_KEY,lang);
document.documentElement.lang=lang;
document.documentElement.dir=lang==="ar"?"rtl":"ltr";
document.body.classList.toggle("ltr",lang==="en");

document.querySelectorAll("[data-i18n]").forEach(e=>{
const k=e.dataset.i18n;
if(tr[lang][k])e.textContent=tr[lang][k];
});

document.querySelectorAll("[data-i18n-placeholder]").forEach(e=>{
e.placeholder=t(e.dataset.i18nPlaceholder);
});

$("#languageBtn").textContent=lang==="ar"?"EN":"ع";

renderHistory();
renderMessages();
renderPrompts();
}

function save(){
try{
localStorage.setItem(HISTORY_KEY,JSON.stringify(chats.slice(0,60)));
}catch{
toast("Storage is full. Export old conversations and clear some history.");
}
}

function load(){
try{
const x=JSON.parse(localStorage.getItem(HISTORY_KEY)||"[]");
if(Array.isArray(x))chats=x;
}catch{
chats=[];
}

currentId=chats[0]?.id||null;
renderHistory();

if(currentId){
renderMessages();
showMessages();
}
}

function current(){
return chats.find(c=>c.id===currentId);
}

function createChat(){
const c={
id:crypto.randomUUID(),
title:t("untitled"),
messages:[],
updated:Date.now()
};

chats.unshift(c);
currentId=c.id;

save();
renderHistory();
renderMessages();
showWelcome();
input.focus();
closeSidebar();

$("#pageTitle").textContent=t("assistant");

document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));
$("#assistantNav").classList.add("active");
}

function showWelcome(){
welcome.classList.remove("hidden");
messagesEl.classList.remove("visible");
$("#promptLibrary").classList.add("hidden");
}

function showMessages(){
welcome.classList.add("hidden");
messagesEl.classList.add("visible");
$("#promptLibrary").classList.add("hidden");
}

function renderHistory(){
const list=$("#historyList");
const query=$("#historySearch").value.toLowerCase().trim();

list.innerHTML="";

const found=chats.filter(c=>c.title.toLowerCase().includes(query));

if(!found.length){
const d=document.createElement("div");
d.className="history-item";
d.textContent=t("empty");
list.append(d);
return;
}

found.slice(0,20).forEach(c=>{
const b=document.createElement("button");

b.className="history-item"+(c.id===currentId?" selected":"");
b.textContent=c.title;
b.title=c.title;

b.onclick=()=>{
currentId=c.id;
renderHistory();
renderMessages();
showMessages();
closeSidebar();

$("#pageTitle").textContent=c.title;

document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));
$("#historyNav").classList.add("active");
};

list.append(b);
});
}

function appendMessage(role,content,scroll=true){
const node=$("#messageTemplate").content.cloneNode(true);
const wrap=node.querySelector(".message");
const av=node.querySelector(".message-avatar");
const label=node.querySelector(".message-role");
const body=node.querySelector(".message-content");
const copy=node.querySelector('[data-action="copy"]');

wrap.classList.add(role);
av.textContent=role==="user"?"●":"✳";
label.textContent=role==="user"?t("you"):t("ai");
body.textContent=content;
copy.textContent=language==="ar"?"نسخ":"Copy";

copy.onclick=async()=>{
try{
await navigator.clipboard.writeText(body.textContent);
toast(t("copied"));
}catch{
toast("Clipboard unavailable");
}
};

messagesEl.append(node);

if(scroll)messagesEl.scrollTop=messagesEl.scrollHeight;

return messagesEl.lastElementChild.querySelector(".message-content");
}

function renderMessages(){
messagesEl.innerHTML="";

const c=current();

if(!c||!c.messages.length){
showWelcome();
return;
}

c.messages.forEach(m=>appendMessage(m.role,m.content,false));

showMessages();
messagesEl.scrollTop=messagesEl.scrollHeight;
}

function renderPrompts(){
const items=[
[
"مراجعة كود",
"راجع الكود كمهندس برمجيات. حدّد الأخطاء والمخاطر، ثم أعطني الملف الكامل المصحح وخطوات الاختبار.",
"حلّل هذا الكود كمراجع برمجي خبير. حدّد الأخطاء والمخاطر، ثم اقترح إصلاحاً دقيقاً وقدم الملف الكامل المصحح عند توفر السياق."
],
[
"خطة مشروع",
"أنشئ خطة تنفيذ بمراحل وأولويات ومخاطر ومخرجات قابلة للقياس.",
"أنشئ خطة تنفيذ احترافية لهذا المشروع تشمل نطاق العمل، المراحل، الأولويات، المخاطر، المخرجات، ومعايير النجاح."
],
[
"بحث معمق",
"افصل الحقائق المؤكدة عن الافتراضات واذكر ما يحتاج إلى تحقق.",
"حلّل الموضوع بعمق. افصل الحقائق المؤكدة عن الافتراضات، وضح القيود، واذكر ما يحتاج إلى تحقق قبل اتخاذ القرار."
],
[
"كتابة احترافية",
"اكتب نصاً واضحاً ومنظماً يناسب الهدف والجمهور.",
"ساعدني في إعداد نص احترافي مناسب للجمهور والهدف. اجعله واضحاً ومنظماً ودقيقاً، ولا تخترع معلومات غير متوفرة."
],
[
"تشخيص خطأ",
"ابدأ بالاحتمالات الأقرب ثم قدّم خطوات تشخيص قابلة للتنفيذ.",
"ساعدني في تشخيص المشكلة التقنية. رتّب الأسباب المحتملة حسب الترجيح، ثم أعطني خطوات اختبار متدرجة، واشرح كيف أفسر النتائج."
],
[
"تعلم خطوة بخطوة",
"اشرح الفكرة مع مثال عملي ثم اختبار قصير للتحقق من الفهم.",
"اشرح لي هذا الموضوع خطوة بخطوة بلغة واضحة، مع مثال عملي، ثم قائمة تحقق قصيرة للتأكد من فهمي."
]
];

const grid=$("#promptGrid");
grid.innerHTML="";

items.forEach(([title,desc,prompt])=>{
const card=document.createElement("article");
card.className="prompt-card";

const h=document.createElement("strong");
h.textContent=title;

const p=document.createElement("p");
p.textContent=desc;

const b=document.createElement("button");
b.textContent=language==="ar"?"استخدم القالب":"Use template";

b.onclick=()=>{
input.value=prompt;
resizeInput();
input.focus();

$("#promptLibrary").classList.add("hidden");
showWelcome();
closeSidebar();
};

card.append(h,p,b);
grid.append(card);
});
}

async function checkStatus(){
try{
const r=await fetch("/api/config");

if(r.status===401){
showLogin();
return;
}

const c=await r.json();

$("#connectionText").textContent=c.configured?t("connected"):t("notConfigured");
$("#statusOrb").classList.toggle("ok",!!c.configured);

}catch{
$("#connectionText").textContent=t("connectionError");
$("#statusOrb").classList.remove("ok");
}
}

async function loadModels(){
try{
const r=await fetch("/api/models");

if(r.status===401)return showLogin();

const x=await r.json();

modelSelect.innerHTML="";

(x.data||[]).forEach(m=>{
const o=document.createElement("option");
o.value=m.id;
o.textContent=m.name||m.id;
modelSelect.append(o);
});

if(!modelSelect.options.length){
const o=document.createElement("option");
o.value="";
o.textContent=t("loadModels");
modelSelect.append(o);
}

}catch{
modelSelect.innerHTML='<option value="">Default model</option>';
}
}

function showLogin(){
loggedIn=false;
$("#appShell").classList.add("hidden");
$("#loginGate").classList.remove("hidden");
setTimeout(()=>$("#passwordInput").focus(),80);
}

function showApp(){
loggedIn=true;
$("#loginGate").classList.add("hidden");
$("#appShell").classList.remove("hidden");

load();
checkStatus();
loadModels();
}

async function sendMessage(raw){
const text=raw.trim();

if(!text||busy)return;

if(!current())createChat();

const c=current();
let finalText=text;

if(attachments.length){
finalText+="\n\n--- Attached text files ---\n"+
attachments.map(f=>`FILE: ${f.name}\n${f.content}`).join("\n\n---\n\n");

attachments=[];
renderAttachments();
}

c.messages.push({role:"user",content:finalText});

if(c.messages.filter(m=>m.role==="user").length===1){
c.title=text.slice(0,44)+(text.length>44?"…":"");
}

c.updated=Date.now();

save();
renderHistory();
appendMessage("user",finalText);
showMessages();

input.value="";
resizeInput();

busy=true;
sendBtn.disabled=true;

const output=appendMessage("assistant","");

output.innerHTML='<span class="typing"><i></i><i></i><i></i></span>';

try{
const r=await fetch("/api/chat",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({
messages:c.messages.slice(-40).map(m=>({
role:m.role,
content:m.content
})),
model:modelSelect.value||undefined,
stream:true
})
});

if(r.status===401){
showLogin();
throw new Error("Login expired.");
}

if(!r.ok){
let err={};

try{
err=await r.json();
}catch{}

throw new Error(
[err.error,err.detail].filter(Boolean).join(" — ")||`HTTP ${r.status}`
);
}

const reader=r.body.getReader();
const decoder=new TextDecoder();

let buffer="";
let answer="";
let got=false;

while(true){
const {done,value}=await reader.read();

if(done)break;

buffer+=decoder.decode(value,{stream:true});

const chunks=buffer.split(/\r?\n\r?\n/);
buffer=chunks.pop()||"";

for(const chunk of chunks){
for(const line of chunk.split(/\r?\n/)){
if(!line.startsWith("data:"))continue;

const data=line.slice(5).trim();

if(data==="[DONE]")continue;

try{
const obj=JSON.parse(data);
const delta=obj.choices?.[0]?.delta?.content??obj.choices?.[0]?.message?.content;

if(typeof delta==="string"){
if(!got){
output.textContent="";
got=true;
}

answer+=delta;
output.textContent=answer;
messagesEl.scrollTop=messagesEl.scrollHeight;
}
}catch{}
}
}
}

if(!answer.trim()){
answer=language==="ar"
?"لم يصل رد نصي من النموذج. تحقق من معرّف النموذج وإعدادات البوابة."
:"No response text was returned. Check the model ID and gateway configuration.";
}

output.textContent=answer;

c.messages.push({role:"assistant",content:answer});
c.updated=Date.now();

save();
renderHistory();

}catch(e){
output.textContent=t("requestError")+(e.message?`\n${e.message}`:"");
output.parentElement.parentElement.classList.add("error");

}finally{
busy=false;
sendBtn.disabled=false;
input.focus();
}
}

function resizeInput(){
input.style.height="auto";
input.style.height=Math.min(input.scrollHeight,160)+"px";
}

function renderAttachments(){
const bar=$("#attachmentBar");

bar.innerHTML="";
bar.classList.toggle("hidden",!attachments.length);

attachments.forEach((f,i)=>{
const pill=document.createElement("span");
pill.className="attachment-pill";
pill.textContent=f.name;

const b=document.createElement("button");
b.textContent="×";

b.onclick=()=>{
attachments.splice(i,1);
renderAttachments();
};

pill.append(b);
bar.append(pill);
});
}

function exportChat(){
const c=current();

if(!c||!c.messages.length)return toast(t("noMessages"));

const blob=new Blob([
JSON.stringify({
app:"Aether AI Workspace Pro",
exportedAt:new Date().toISOString(),
conversation:c
},null,2)
],{type:"application/json"});

const a=document.createElement("a");

a.href=URL.createObjectURL(blob);
a.download=(c.title||"aether-chat")
.replace(/[^\p{L}\p{N}_-]+/gu,"-")
.slice(0,50)+".json";

a.click();

URL.revokeObjectURL(a.href);
}

async function init(){
document.body.classList.toggle(
"light-theme",
localStorage.getItem(THEME_KEY)==="light"
);

setLanguage(language);

const r=await fetch("/api/session");
const s=await r.json();

if(!s.loginConfigured){
showLogin();
$("#loginError").textContent=t("loginMissing");
$("#passwordInput").disabled=true;
$("#loginForm button").disabled=true;
return;
}

if(s.authenticated){
showApp();
}else{
showLogin();
}
}

form.addEventListener("submit",e=>{
e.preventDefault();
sendMessage(input.value);
});

input.addEventListener("input",resizeInput);

input.addEventListener("keydown",e=>{
if(e.key==="Enter"&&!e.shiftKey){
e.preventDefault();
form.requestSubmit();
}
});

$("#loginForm").addEventListener("submit",async e=>{
e.preventDefault();

const b=e.submitter;
b.disabled=true;

$("#loginError").textContent="";

try{
const r=await fetch("/api/login",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({
password:$("#passwordInput").value
})
});

const x=await r.json();

if(!r.ok)throw new Error(x.error||"Login failed");

$("#passwordInput").value="";
showApp();

}catch(err){
$("#loginError").textContent=err.message;

}finally{
b.disabled=false;
}
});

$("#newChat").onclick=createChat;

$("#assistantNav").onclick=()=>{
showWelcome();

$("#pageTitle").textContent=t("assistant");

document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));

$("#assistantNav").classList.add("active");

closeSidebar();
};

$("#historyNav").onclick=()=>{
if(chats.length){
currentId=chats[0].id;

renderHistory();
renderMessages();
showMessages();

}else{
toast(t("empty"));
showWelcome();
}

$("#pageTitle").textContent=t("history");

document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));

$("#historyNav").classList.add("active");

closeSidebar();
};

$("#promptsNav").onclick=()=>{
welcome.classList.add("hidden");
messagesEl.classList.remove("visible");

$("#promptLibrary").classList.remove("hidden");
$("#pageTitle").textContent=t("promptLibrary");

renderPrompts();

document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));

$("#promptsNav").classList.add("active");

closeSidebar();
};

$("#clearBtn").onclick=()=>{
if(!current())return;

if(!confirm(t("clearConfirm")))return;

current().messages=[];

save();
renderMessages();
showWelcome();
};

$("#exportBtn").onclick=exportChat;

$("#themeBtn").onclick=()=>{
document.body.classList.toggle("light-theme");

localStorage.setItem(
THEME_KEY,
document.body.classList.contains("light-theme")?"light":"dark"
);
};

$("#languageBtn").onclick=()=>{
setLanguage(language==="ar"?"en":"ar");
};

$("#menuBtn").onclick=()=>{
$("#sidebar").classList.toggle("open");
};

$("#refreshStatus").onclick=()=>{
checkStatus();
loadModels();
};

$("#searchToggle").onclick=()=>{
$("#historySearch").classList.toggle("hidden");
$("#historySearch").focus();
};

$("#historySearch").oninput=renderHistory;

$("#logoutBtn").onclick=async()=>{
await fetch("/api/logout",{method:"POST"});
showLogin();
};

document.querySelectorAll(".suggestion").forEach(b=>{
b.onclick=()=>{
input.value=b.dataset.prompt;
resizeInput();
sendMessage(input.value);
closeSidebar();
};
});

$("#fileInput").addEventListener("change",async e=>{
for(const file of [...e.target.files]){
if(file.size>150*1024){
toast(t("fileLarge"));
continue;
}

try{
const content=await file.text();

attachments.push({
name:file.name,
content:content.slice(0,30000)
});

}catch{
toast(t("fileRead"));
}
}

e.target.value="";

renderAttachments();

if(attachments.length)toast(t("filesAdded"));
});

document.addEventListener("keydown",e=>{
if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){
e.preventDefault();
createChat();
}

if(e.key==="Escape"){
closeSidebar();
}
});

init();
